WIDTH = 400
HEIGHT = 700

bird = Actor('bird', (75, 150))


def update():
    #kod för update
    pass

def draw():
    #kod för draw
    screen.clear()
    bird.draw()
